#!/usr/bin/env python3
"""
Personal Expense Tracker - CLI (standard library only)
Usage: python3 app.py
"""
import csv
import os
import sys
import tempfile
from datetime import datetime
from typing import List, Dict, Tuple

FILENAME = os.environ.get("EXPENSE_FILE", "expenses.csv")
DATE_FMT = "%Y-%m-%d %H:%M:%S"
CSV_FIELDS = ["date", "amount", "category", "note"]


def now_str() -> str:
    return datetime.now().strftime(DATE_FMT)


def safe_float(s: str) -> Tuple[bool, float]:
    try:
        v = float(s)
        return True, v
    except Exception:
        return False, 0.0


def parse_date_try(s: str) -> datetime:
    fmts = ["%Y-%m-%d %H:%M:%S", "%Y-%m-%d", "%d-%m-%Y", "%d/%m/%Y", "%Y/%m/%d"]
    last_exc = None
    for f in fmts:
        try:
            return datetime.strptime(s, f)
        except Exception as e:
            last_exc = e
    raise last_exc or ValueError("Unrecognized date format")


def ensure_file():
    if not os.path.exists(FILENAME):
        with open(FILENAME, "w", newline="", encoding="utf-8") as f:
            writer = csv.DictWriter(f, fieldnames=CSV_FIELDS)
            writer.writeheader()


def read_expenses() -> Tuple[List[Dict[str,str]], int]:
    rows = []
    skipped = 0
    if not os.path.exists(FILENAME):
        return rows, skipped
    with open(FILENAME, "r", newline="", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        for r in reader:
            if not any((v and v.strip()) for v in r.values()):
                skipped += 1
                continue
            if "amount" not in r or not r.get("amount"):
                skipped += 1
                continue
            ok, amt = safe_float(r.get("amount", "").strip())
            if not ok:
                skipped += 1
                continue
            row = {
                "date": r.get("date", "").strip() or "",
                "amount": f"{amt:.2f}",
                "category": (r.get("category") or "Misc").strip(),
                "note": (r.get("note") or "").strip(),
            }
            rows.append(row)
    return rows, skipped


def write_expenses(rows: List[Dict[str,str]]):
    dirpath = os.path.dirname(os.path.abspath(FILENAME)) or "."
    fd, temp_path = tempfile.mkstemp(dir=dirpath, prefix="._tmp_exp_")
    os.close(fd)
    try:
        with open(temp_path, "w", newline="", encoding="utf-8") as f:
            writer = csv.DictWriter(f, fieldnames=CSV_FIELDS)
            writer.writeheader()
            for r in rows:
                writer.writerow(r)
        if os.path.exists(FILENAME):
            ts = datetime.now().strftime("%Y%m%d%H%M%S")
            backup = f"{FILENAME}.bak.{ts}"
            try:
                os.replace(FILENAME, backup)
            except Exception:
                pass
        os.replace(temp_path, FILENAME)
    finally:
        if os.path.exists(temp_path):
            os.remove(temp_path)


def add_expense():
    ensure_file()
    print("\nAdd Expense (type 'q' to cancel anytime)")
    while True:
        amt_in = input("Enter amount (e.g., 199.50): ").strip()
        if amt_in.lower() == "q":
            print("Add cancelled.")
            return
        ok, amt = safe_float(amt_in)
        if not ok or amt < 0:
            print("❌ Invalid amount. Enter a positive number.")
            continue
        break
    category = input("Category (Food, Travel, Shopping) [default: Misc]: ").strip() or "Misc"
    note = input("Note (optional): ").strip()
    if input("Use custom date? (y/N): ").strip().lower() == "y":
        while True:
            dstr = input("Enter date (YYYY-MM-DD or YYYY-MM-DD HH:MM:SS): ").strip()
            try:
                dt = parse_date_try(dstr)
                date_str = dt.strftime(DATE_FMT)
                break
            except Exception:
                print("❌ Unrecognized date. Try 2025-10-03 or 2025-10-03 15:30:00.")
    else:
        date_str = now_str()

    rows, _ = read_expenses()
    rows.append({
        "date": date_str,
        "amount": f"{amt:.2f}",
        "category": category,
        "note": note,
    })
    write_expenses(rows)
    print("✅ Expense added successfully!")


def view_expenses(limit: int = 0, show_index: bool = True):
    rows, skipped = read_expenses()
    if not rows:
        print("⚠️ No expenses recorded yet.")
        return
    print("\nView options: [Enter] show all | 'c' filter by category | 'd' filter by date range")
    choice = input("Choose filter or press enter: ").strip().lower()
    filtered = rows
    if choice == "c":
        cat = input("Category to filter: ").strip()
        filtered = [r for r in rows if r["category"].lower() == cat.lower()]
    elif choice == "d":
        print("Enter start date (YYYY-MM-DD) or leave blank for start of records.")
        s = input("Start date: ").strip()
        e = input("End date (YYYY-MM-DD) or leave blank for today: ").strip()
        try:
            start_dt = parse_date_try(s) if s else datetime.min
            end_dt = parse_date_try(e) if e else datetime.now()
            def in_range(r):
                try:
                    dt = datetime.strptime(r["date"], DATE_FMT)
                    return start_dt <= dt <= end_dt
                except Exception:
                    return False
            filtered = [r for r in rows if in_range(r)]
        except Exception:
            print("⚠️ Date parse error — showing all.")
    if limit and len(filtered) > limit:
        filtered = filtered[-limit:]

    date_w = 19
    amt_w = 12
    cat_w = max(10, max(len(r["category"]) for r in filtered))
    note_w = 30
    header = f"{'Idx' if show_index else '' :4} {'Date':{date_w}} {'Amount':{amt_w}} {'Category':{cat_w}} {'Note':{note_w}}"
    print("\n" + header)
    print("-" * (4 + 1 + date_w + 1 + amt_w + 1 + cat_w + 1 + note_w))
    for i, r in enumerate(filtered, start=1):
        idx = f"{i:3}" if show_index else ""
        note = (r["note"][:(note_w-3)] + "...") if len(r["note"]) > note_w else r["note"]
        print(f"{idx:4} {r['date']:{date_w}} {('₹' + r['amount']):{amt_w}} {r['category']:{cat_w}} {note:{note_w}}")
    if skipped:
        print(f"\n⚠️ Skipped {skipped} malformed/blank rows while reading the file.")


def expense_summary():
    rows, skipped = read_expenses()
    if not rows:
        print("⚠️ No expenses recorded yet.")
        return
    total = 0.0
    categories = {}
    for r in rows:
        try:
            amt = float(r["amount"])
        except Exception:
            continue
        total += amt
        categories[r["category"]] = categories.get(r["category"], 0.0) + amt
    avg = total / len(rows) if rows else 0.0
    top_cats = sorted(categories.items(), key=lambda x: x[1], reverse=True)[:5]

    print("\n--- Expense Summary ---")
    print(f"Records: {len(rows)}")
    print(f"Total Spent: ₹{total:.2f}")
    print(f"Average per Record: ₹{avg:.2f}")
    print("\nBy Category:")
    for cat, val in top_cats:
        pct = (val / total * 100) if total else 0
        print(f" - {cat}: ₹{val:.2f} ({pct:.1f}%)")
    if skipped:
        print(f"\n⚠️ Skipped {skipped} malformed/blank rows while reading the file.")


def export_report():
    rows, skipped = read_expenses()
    if not rows:
        print("⚠️ No expenses recorded yet.")
        return
    txt_file = "expense_report.txt"
    summary_csv = "expense_summary.csv"
    json_file = "expense_backup.json"
    total = sum(float(r["amount"]) for r in rows)
    with open(txt_file, "w", encoding="utf-8") as out:
        out.write("Expense Report\n")
        out.write("====================\n")
        out.write(f"Generated: {now_str()}\n")
        out.write(f"Records: {len(rows)}\n")
        out.write(f"Total Spent: ₹{total:.2f}\n\n")
        out.write("All records:\n")
        for r in rows:
            out.write(f"{r['date']} | ₹{r['amount']} | {r['category']} | {r['note']}\n")
    categories = {}
    for r in rows:
        categories[r["category"]] = categories.get(r["category"], 0.0) + float(r["amount"])
    with open(summary_csv, "w", newline="", encoding="utf-8") as f:
        writer = csv.writer(f)
        writer.writerow(["category", "total"])
        for k, v in categories.items():
            writer.writerow([k, f"{v:.2f}"])
    import json
    with open(json_file, "w", encoding="utf-8") as f:
        json.dump(rows, f, indent=2)
    print(f"📄 Reports exported: {txt_file}, {summary_csv}, {json_file}")


def select_index(max_idx: int, prompt: str = "Enter record index: ") -> int:
    while True:
        s = input(prompt).strip()
        if s.lower() == "q":
            return -1
        if not s.isdigit():
            print("❌ Enter a number or 'q' to cancel.")
            continue
        i = int(s)
        if i < 1 or i > max_idx:
            print(f"❌ Index out of range (1..{max_idx}).")
            continue
        return i - 1


def update_expense():
    rows, skipped = read_expenses()
    if not rows:
        print("⚠️ No expenses recorded yet.")
        return
    view_expenses(show_index=True)
    idx = select_index(len(rows), "Index of record to update (or 'q' to cancel): ")
    if idx == -1:
        print("Update cancelled.")
        return
    rec = rows[idx]
    print(f"Selected: {rec['date']} | ₹{rec['amount']} | {rec['category']} | {rec['note']}")
    new_amt = input(f"New amount [enter to keep ₹{rec['amount']}]: ").strip()
    if new_amt:
        ok, v = safe_float(new_amt)
        if ok and v >= 0:
            rec["amount"] = f"{v:.2f}"
        else:
            print("Invalid amount input — keeping old value.")
    new_cat = input(f"New category [enter to keep {rec['category']}]: ").strip()
    if new_cat:
        rec["category"] = new_cat
    new_note = input(f"New note [enter to keep current note]: ").strip()
    if new_note:
        rec["note"] = new_note
    if input("Change date? (y/N): ").strip().lower() == "y":
        dstr = input("Enter date (YYYY-MM-DD or YYYY-MM-DD HH:MM:SS): ").strip()
        try:
            rec["date"] = parse_date_try(dstr).strftime(DATE_FMT)
        except Exception:
            print("Invalid date format — keeping old date.")
    rows[idx] = rec
    write_expenses(rows)
    print("✅ Record updated.")


def delete_expense():
    rows, skipped = read_expenses()
    if not rows:
        print("⚠️ No expenses recorded yet.")
        return
    view_expenses(show_index=True)
    idx = select_index(len(rows), "Index of record to delete (or 'q' to cancel): ")
    if idx == -1:
        print("Delete cancelled.")
        return
    print(f"About to delete: {rows[idx]['date']} | ₹{rows[idx]['amount']} | {rows[idx]['category']}")
    if input("Confirm delete? (type 'yes' to confirm): ").strip().lower() == "yes":
        rows.pop(idx)
        write_expenses(rows)
        print("✅ Deleted.")
    else:
        print("Delete cancelled.")


def show_help():
    print("\nThis is a small CLI Personal Expense Tracker.")
    print("Files created/used:")
    print(f" - {FILENAME} (primary data file, CSV with header)")
    print(" - expense_report.txt, expense_summary.csv, expense_backup.json (exports)")
    print("Tips:")
    print(" - You can set EXPENSE_FILE environment variable to change where data is stored.")
    print(" - Use 'q' to cancel many operations.")


def main_menu():
    ensure_file()
    while True:
        print("\n==== Personal Expense Tracker ====")
        print("1. Add Expense")
        print("2. View Expenses")
        print("3. Expense Summary")
        print("4. Update Expense")
        print("5. Delete Expense")
        print("6. Export Report")
        print("7. Help / Files")
        print("8. Exit")
        choice = input("Enter choice (1-8): ").strip()
        if choice == "1":
            add_expense()
        elif choice == "2":
            lim = input("Show last N records? (enter N or press enter for all): ").strip()
            try:
                n = int(lim) if lim else 0
            except Exception:
                n = 0
            view_expenses(limit=n)
        elif choice == "3":
            expense_summary()
        elif choice == "4":
            update_expense()
        elif choice == "5":
            delete_expense()
        elif choice == "6":
            export_report()
        elif choice == "7":
            show_help()
        elif choice == "8":
            print("👋 Goodbye! Keep tracking your expenses.")
            break
        else:
            print("❌ Invalid choice. Please enter 1-8.")


if __name__ == "__main__":
    try:
        main_menu()
    except KeyboardInterrupt:
        print("\nInterrupted. Bye.")
        sys.exit(0)