# How to run
Extract the zip file anywhere on your computer.
Go to the extracted folder(where app.py is located).
Run the app:
Windows: python app.py
macOS / Linux: python3 app.py

Use the menu:
Type 1 → Add Expense
Type 2 → View Expenses
Type 3 → Expense Summary
Type 4 → Update Expense
Type 5 → Delete Expense
Type 6 → Export Report
Type 7 → Help / Files
Type 8 → Exit

## Tips:
You can type q in many prompts to cancel an action.
Enter invalid input (like letters for amount) to see friendly error handling — the program will not crash.
After exporting, check files: expense_report.txt, expense_summary.csv, expense_backup.json.
The primary data file expenses.csv is created automatically on first run.
Optional: Use a custom CSV file:


# Files
app.py — main CLI program (run this).
expenses.csv — primary data file (CSV with header: date,amount,category,note). Created automatically.
date stored as YYYY-MM-DD HH:MM:SS
amount stored with two decimals (e.g., 199.50)
category short string (e.g., Food, Travel)
note optional short text
expense_report.txt — human-readable exported report (generated via Export option).
expense_summary.csv — per-category totals (generated).
expense_backup.json — JSON backup of records (generated).
README.md — this file.



# Personal Expense Tracker — Team Twins (UT7O16X7)

A small *command-line Personal Expense Tracker*. It lets you add / view / update / delete expense records and saves them to a CSV file (`expenses.csv`). It also generates export files (`expense_report.txt`, `expense_summary.csv`, `expense_backup.json`). Written using Python 3 standard library only, and handles invalid input gracefully.


# Notes / AI Disclosure

This project is built entirely by *Team Twins* (Spoorti A. Menasagi & Keerti A. Menasagi) for the BMIET Vibe Coding — Python Track (Beginner).

The CLI tool reads and writes simple files (expenses.csv) and generates output files (expense_report.txt, expense_summary.csv, expense_backup.json).
The project follows all event rules: uses Python 3 standard library only, handles invalid input gracefully, and performs file read/write operations safely.
AI Assistance: Some code refinement and structure suggestions were obtained from ChatGPT. All final code, testing, and adaptation were done by the team.
No external packages are used; the program is fully compatible with lab machines.
Sample input files (expenses.csv) and generated output files are included for demonstration.